import java.util.*;

public class Character {

}
