import java.util.*;

public class ItemList {
	ArrayList<Item> items;
	int nextID;
	
	
}
